import json
import os
from ..core.sprite_project import SpriteProject, Animation, Frame

PROJECT_FOLDER = "data/sprite_projects"

def load_or_create_project(sprite_id):

    os.makedirs(PROJECT_FOLDER, exist_ok=True)

    path = f"{PROJECT_FOLDER}/{sprite_id}.json"

    if os.path.exists(path):

        return load_sprite(path)

    else:

        project = SpriteProject()

        project.sprite_id = sprite_id
        project.sheet_file = f"assets/sprites/{sprite_id}.png"

        return project

def load_sprite(path):

    if not os.path.exists(path):
        print("Sprite file not found:", path)
        return None

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    project = SpriteProject()

    # -------------------------
    # BASIC DATA
    # -------------------------

    project.name = data.get("name", "")
    project.sprite_id = data.get("sprite_id", 0)
    project.sheet_file = data.get("sheet", None)

    animations = data.get("animations", {})

    # -------------------------
    # LOAD ANIMATIONS
    # -------------------------

    for anim_name, anim_data in animations.items():

        animation = Animation(anim_name)

        animation.speed = anim_data.get("speed", 0.08)
        animation.loop = anim_data.get("loop", True)
        animation.pingpong = anim_data.get("pingpong", False)

        frames = anim_data.get("frames", [])

        # -------------------------
        # LOAD FRAMES
        # -------------------------

        for f in frames:

            rect = f.get("rect", [0, 0, 0, 0])

            frame = Frame(
                rect[0],
                rect[1],
                rect[2],
                rect[3]
            )

            origin = f.get("origin", [0, 0])
            frame.origin_x = origin[0]
            frame.origin_y = origin[1]

            offset = f.get("offset", [0, 0])
            frame.offset_x = offset[0]
            frame.offset_y = offset[1]

            frame.hitboxes = f.get("hitboxes", [])
            frame.hurtboxes = f.get("hurtboxes", [])

            animation.frames.append(frame)

        project.animations[anim_name] = animation

    print("Sprite loaded:", project.name)

    return project