import pygame
from game.session import session


class SpriteList:

    def __init__(self, editor):

        self.editor = editor
        self.items = []

    def draw(self, screen):

        rect = self.editor.layout.sprite_list

        font = pygame.font.SysFont("arial",16)

        y = rect.y + 10

        self.items.clear()

        for sprite in session.sprite_list:

            r = pygame.Rect(rect.x+10,y,rect.width-20,24)

            pygame.draw.rect(screen,(70,70,70),r)

            txt = font.render(sprite["name"],True,(220,220,220))

            screen.blit(txt,(r.x+5,r.y+4))

            self.items.append((r,sprite["id"]))

            y += 30

    def handle_event(self,event):

        if event.type == pygame.MOUSEBUTTONDOWN:

            mx,my = pygame.mouse.get_pos()

            for rect,sprite_id in self.items:

                if rect.collidepoint(mx,my):

                    from network.sender import request_sprite_project

                    request_sprite_project(
                        self.editor.client_socket,
                        sprite_id
                    )