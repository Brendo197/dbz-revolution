import pygame
import tkinter as tk
from tkinter import simpledialog
import os
class AnimationList:

    def __init__(self, editor):

        self.editor = editor
        self.state = editor.state

        self.items = []
        self.rects = []

        self.add_rect = pygame.Rect(0,0,0,0)
        self.scroll = 0
        self.max_scroll = 0
    # -------------------------
    # EVENTS
    # -------------------------

    def handle_event(self, event):
        if event.type == pygame.MOUSEWHEEL:

            mx, my = pygame.mouse.get_pos()

            rect = self.editor.layout.animation_list

            if rect.collidepoint(mx, my):

                self.scroll -= event.y * 20

                if self.scroll < 0:
                    self.scroll = 0

                if self.scroll > self.max_scroll:
                    self.scroll = self.max_scroll
        if event.type == pygame.MOUSEBUTTONDOWN:

            mx, my = pygame.mouse.get_pos()

            # clicar animação
            for i, r in enumerate(self.rects):

                if r.collidepoint(mx,my):

                    name = self.items[i]

                    self.state.set_animation(name)
                    print("CURRENT:", self.state.current_animation)
                    print("ANIMATION SELECTED:", name)

                    # carregar sheet se existir
                    if self.state.project:
                        sprite_id = self.state.project.id

                        sheet_path = os.path.join("assets/sprites", f"{sprite_id}.png")

                        if os.path.exists(sheet_path):
                            self.editor.canvas.load_sheet(sheet_path)
                        else:
                            print("Sprite sheet não encontrada:", sheet_path)

                    return

            # botão add
            if self.add_rect.collidepoint(mx,my):

                self.create_animation()

    # -------------------------
    # CREATE ANIMATION
    # -------------------------

    def create_animation(self):

        project = self.state.project

        if not project:
            return

        # criar janela invisível do tkinter
        root = tk.Tk()
        root.withdraw()

        name = simpledialog.askstring("Nova Animação", "Digite o nome da animação:")

        root.destroy()

        # cancelou
        if not name:
            return

        # evitar nomes duplicados
        if name in project.animations:
            print("Animation já existe!")
            return

        project.add_animation(name)

        self.state.set_animation(name)

    # -------------------------
    # DRAW
    # -------------------------

    def draw(self, screen):

        rect = self.editor.layout.animation_list

        pygame.draw.rect(screen,(35,35,35),rect)

        font = pygame.font.SysFont("arial",16)
        title = font.render("ANIMATIONS", True, (180, 180, 180))
        screen.blit(title, (rect.x + 6, rect.y - 18))
        pygame.draw.line(screen, (60, 60, 60), (rect.x, rect.y - 4), (rect.right, rect.y - 4))
        self.items = []
        self.rects = []

        if not self.state.project:
            return

        y = rect.y + 10 - self.scroll

        for name in self.state.project.animations.keys():

            item_rect = pygame.Rect(rect.x + 5, y, rect.width - 10, 22)

            if item_rect.bottom < rect.y or item_rect.top > rect.bottom:
                y += 26
                continue

            mx, my = pygame.mouse.get_pos()

            if name == self.state.current_animation:
                color = (70, 120, 200)
            elif item_rect.collidepoint(mx, my):
                color = (80, 80, 80)
            else:
                color = (60, 60, 60)

            pygame.draw.rect(screen, color, item_rect)

            if name == self.state.current_animation:
                pygame.draw.rect(screen, (120, 180, 255), item_rect, 2)
                text = font.render("> " + name, True, (255, 255, 255))
            else:
                text = font.render(name, True, (220, 220, 220))

            screen.blit(text, (item_rect.x + 6, item_rect.y + 3))

            self.items.append(name)
            self.rects.append(item_rect)

            y += 26

        # botão add

        self.add_rect = pygame.Rect(rect.x+5,rect.bottom-30,rect.width-10,24)

        mx, my = pygame.mouse.get_pos()

        if self.add_rect.collidepoint(mx, my):
            color = (110, 110, 110)
        else:
            color = (90, 90, 90)

        pygame.draw.rect(screen, color, self.add_rect)

        text = font.render("+ Add", True, (255, 255, 255))

        content_height = len(self.state.project.animations) * 26
        visible_height = rect.height - 40

        self.max_scroll = max(0, content_height - visible_height)

        screen.blit(
            text,
            (
                self.add_rect.centerx - text.get_width() // 2,
                self.add_rect.centery - text.get_height() // 2
            )
        )
        if self.max_scroll > 0:

            bar_height = max(20, rect.height * (visible_height / (content_height + visible_height)))

            scroll_ratio = 0 if self.max_scroll == 0 else self.scroll / self.max_scroll

            bar_y = rect.y + scroll_ratio * (rect.height - bar_height)

            bar_rect = pygame.Rect(rect.right-6, bar_y, 4, bar_height)

            pygame.draw.rect(screen,(140,140,140),bar_rect)