import pygame
from tools.sprite_editor.core.animation_player import AnimationPlayer


class AnimationPreview:

    def __init__(self, editor):

        self.editor = editor
        self.player = AnimationPlayer()

        # visual options
        self.show_grid = True
        self.show_onion = True
        self.show_pivot = True

        # zoom
        self.zoom = 1.0
        self.min_zoom = 0.25
        self.max_zoom = 6.0

        # modo edição
        self.fullscreen = False

        # playback
        self.playing = True

        # drag sprite
        self.dragging = False
        self.drag_start = (0, 0)
        self.drag_offset_start = (0, 0)

        self.font = pygame.font.SysFont("consolas", 12)

    # ------------------------------------------------
    # UPDATE
    # ------------------------------------------------

    def update(self, dt):

        anim = self.editor.state.get_current_animation()

        if not anim:
            return

        if self.player.animation != anim:
            self.player.play(anim)

        if hasattr(self.editor.state, "selected_frame"):
            self.player.frame_index = self.editor.state.selected_frame

        # preview normal roda automaticamente
        if not self.fullscreen:
            self.player.update(dt)

        # editor roda se playing
        if self.fullscreen and self.playing:
            self.player.update(dt)

    # ------------------------------------------------
    # INPUT
    # ------------------------------------------------

    def handle_event(self, event):

        if event.type == pygame.KEYDOWN:

            # alternar modo edição
            if event.key == pygame.K_f:
                self.fullscreen = not self.fullscreen

            # play/pause
            elif event.key == pygame.K_SPACE:
                self.playing = not self.playing

            # frames
            elif event.key == pygame.K_RIGHT:
                self.next_frame()

            elif event.key == pygame.K_LEFT:
                self.prev_frame()

            # reset
            elif event.key == pygame.K_r:
                self.player.frame_index = 0

            # offsets (somente modo edição)
            if self.fullscreen:

                if event.key == pygame.K_w:
                    self.adjust_offset(0, -1)

                elif event.key == pygame.K_s:
                    self.adjust_offset(0, 1)

                elif event.key == pygame.K_a:
                    self.adjust_offset(-1, 0)

                elif event.key == pygame.K_d:
                    self.adjust_offset(1, 0)

        # zoom
        if event.type == pygame.MOUSEWHEEL:

            mx, my = pygame.mouse.get_pos()
            rect = self.get_preview_rect()

            if rect.collidepoint(mx, my):

                if event.y > 0:
                    self.zoom *= 1.15
                else:
                    self.zoom *= 0.85

                self.zoom = max(self.min_zoom, min(self.zoom, self.max_zoom))

        # mouse down
        if event.type == pygame.MOUSEBUTTONDOWN:

            if event.button == 1 and self.fullscreen:

                rect = self.get_preview_rect()
                mx, my = pygame.mouse.get_pos()

                if rect.collidepoint(mx, my):

                    frame = self.player.get_frame()

                    if frame:
                        self.dragging = True
                        self.drag_start = (mx, my)
                        self.drag_offset_start = (
                            frame.offset_x,
                            frame.offset_y
                        )

        # mouse up
        if event.type == pygame.MOUSEBUTTONUP:

            if event.button == 1:
                self.dragging = False

        # mouse move
        if event.type == pygame.MOUSEMOTION:

            if self.dragging:

                mx, my = pygame.mouse.get_pos()

                dx = mx - self.drag_start[0]
                dy = my - self.drag_start[1]

                frame = self.player.get_frame()

                if frame:

                    frame.offset_x = self.drag_offset_start[0] + int(dx / self.zoom)
                    frame.offset_y = self.drag_offset_start[1] + int(dy / self.zoom)

                    self.editor.state.selected_frame = self.player.frame_index

    # ------------------------------------------------
    # OFFSET CONTROL
    # ------------------------------------------------

    def adjust_offset(self, dx, dy):

        frame = self.player.get_frame()

        if not frame:
            return

        keys = pygame.key.get_pressed()
        speed = 5 if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] else 1

        frame.offset_x += dx * speed
        frame.offset_y += dy * speed

        self.editor.state.selected_frame = self.player.frame_index

    # ------------------------------------------------
    # FRAME CONTROL
    # ------------------------------------------------

    def next_frame(self):

        anim = self.player.animation

        if not anim:
            return

        self.player.frame_index += 1
        self.player.frame_index %= len(anim.frames)

        self.editor.state.selected_frame = self.player.frame_index

    def prev_frame(self):

        anim = self.player.animation

        if not anim:
            return

        self.player.frame_index -= 1
        self.player.frame_index %= len(anim.frames)

        self.editor.state.selected_frame = self.player.frame_index

    # ------------------------------------------------
    # PREVIEW RECT
    # ------------------------------------------------

    def get_preview_rect(self):

        if self.fullscreen:

            canvas = self.editor.layout.canvas
            timeline = self.editor.layout.timeline

            left = canvas.left
            top = canvas.top

            width = canvas.width
            height = canvas.height + timeline.height

            return pygame.Rect(left, top, width, height)

        return self.editor.layout.preview

    # ------------------------------------------------
    # BACKGROUND
    # ------------------------------------------------

    def draw_background(self, screen, rect):

        size = 16

        for x in range(rect.left, rect.right, size):
            for y in range(rect.top, rect.bottom, size):

                if ((x // size) + (y // size)) % 2:
                    color = (32, 32, 32)
                else:
                    color = (26, 26, 26)

                pygame.draw.rect(screen, color, (x, y, size, size))

    # ------------------------------------------------
    # GRID
    # ------------------------------------------------

    def draw_grid(self, screen, rect):

        if not self.fullscreen:
            return

        size = 32

        for x in range(rect.left, rect.right, size):
            pygame.draw.line(screen,(45,45,45),(x,rect.top),(x,rect.bottom))

        for y in range(rect.top, rect.bottom, size):
            pygame.draw.line(screen,(45,45,45),(rect.left,y),(rect.right,y))

    # ------------------------------------------------
    # DRAW FRAME
    # ------------------------------------------------

    def draw_frame(self, screen, frame, rect, sheet, alpha=255):

        try:

            img = sheet.subsurface(
                int(frame.x),
                int(frame.y),
                int(frame.w),
                int(frame.h)
            ).copy()

        except:
            return None

        if alpha != 255:
            img.set_alpha(alpha)

        scale = min(
            rect.width / frame.w,
            rect.height / frame.h
        ) * self.zoom

        w = int(frame.w * scale)
        h = int(frame.h * scale)

        img = pygame.transform.smoothscale(img, (w, h))

        pivot_x = rect.centerx
        pivot_y = rect.bottom - 30

        draw_x = pivot_x - frame.origin_x * scale + frame.offset_x * scale
        draw_y = pivot_y - frame.origin_y * scale + frame.offset_y * scale

        screen.blit(img, (draw_x, draw_y))

        return draw_x, draw_y, w, h, scale

    # ------------------------------------------------
    # DRAW
    # ------------------------------------------------

    def draw(self, screen):

        frame = self.player.get_frame()

        if not frame:
            return

        sheet = self.editor.canvas.sheet

        if not sheet:
            return

        rect = self.get_preview_rect()

        self.draw_background(screen, rect)
        self.draw_grid(screen, rect)

        # onion
        if self.fullscreen and self.show_onion:

            anim = self.player.animation

            if anim and len(anim.frames) > 1:

                prev_index = (self.player.frame_index - 1) % len(anim.frames)
                prev_frame = anim.frames[prev_index]

                self.draw_frame(screen, prev_frame, rect, sheet, alpha=70)

        result = self.draw_frame(screen, frame, rect, sheet)

        if not result:
            return

        draw_x, draw_y, w, h, scale = result

        # chão
        ground_y = rect.bottom - 30

        pygame.draw.line(
            screen,
            (80,80,80),
            (rect.left, ground_y),
            (rect.right, ground_y),
            2
        )

        # pivot
        if self.fullscreen and self.show_pivot:

            cx = rect.centerx
            cy = ground_y

            pygame.draw.line(screen,(0,200,255),(cx-10,cy),(cx+10,cy),2)
            pygame.draw.line(screen,(0,200,255),(cx,cy-10),(cx,cy+10),2)

        # hit frame
        if frame.attack_frame:

            pygame.draw.rect(
                screen,
                (255,80,80),
                (draw_x, draw_y, w, h),
                2
            )

        # HUD
        anim = self.player.animation

        tick = frame.tick_override if frame.tick_override else anim.tick

        if self.fullscreen:

            info = f"EDIT | Frame {self.player.frame_index}/{len(anim.frames)} | Tick {tick} | Zoom {round(self.zoom,2)}"

        else:

            info = f"Frame {self.player.frame_index}/{len(anim.frames)}"

        txt = self.font.render(info, True, (200,200,200))

        screen.blit(txt, (rect.left + 10, rect.top + 8))

        if self.fullscreen:
            self.draw_player_controls(screen, rect)
    def draw_player_controls(self, screen, rect):

        anim = self.player.animation
        if not anim:
            return

        y = rect.bottom - 40
        x = rect.centerx - 120

        buttons = [
            ("<<", -2),
            ("<", -1),
            ("PLAY", 0),
            (">", 1),
            (">>", 2),
        ]

        for label, action in buttons:
            button_rect = pygame.Rect(x, y, 50, 28)

            pygame.draw.rect(screen, (60, 60, 60), button_rect)
            pygame.draw.rect(screen, (120, 120, 120), button_rect, 1)

            txt = self.font.render(label, True, (220, 220, 220))
            screen.blit(txt, (button_rect.x + 10, button_rect.y + 6))

            x += 55